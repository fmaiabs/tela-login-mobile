package com.pedroza.telaloginregistro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class telaPosLogin : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_pos_login)
        setTitle(R.string.tituloTelaPosLogin)
    }
}
