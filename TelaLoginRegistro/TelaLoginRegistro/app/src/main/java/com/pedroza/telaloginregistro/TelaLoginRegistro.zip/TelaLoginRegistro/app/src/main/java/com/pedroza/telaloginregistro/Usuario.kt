package com.pedroza.telaloginregistro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_tela_de_registro.*

class Usuario : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_usuario)
        setTitle("Usuario")

    //    val email = intent.getStringExtra("endereco")
    //    textView2.text=email

    }
}
